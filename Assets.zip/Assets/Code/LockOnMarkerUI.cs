using UnityEngine;
using UnityEngine.UI;

public class LockOnMarkerUI : MonoBehaviour
{
    [SerializeField] private PlayerController playerController;
    [SerializeField] private Camera mainCamera;
    [SerializeField] private RectTransform markerRect;
    [SerializeField] private Image markerImage;

    [SerializeField] private Vector3 worldOffset = new Vector3(0f, 1.5f, 0f);

    void Start()
    {
        SetMarkerVisible(false);
    }

    void Update()
    {
        Transform target = playerController.CurrentLockOnTarget;

        if (target == null)
        {
            SetMarkerVisible(false);
            return;
        }

        Vector3 worldPosition = target.position + worldOffset;
        Vector3 screenPosition = mainCamera.WorldToScreenPoint(worldPosition);

        if (screenPosition.z < 0f)
        {
            SetMarkerVisible(false);
            return;
        }

        SetMarkerVisible(true);
        markerRect.position = screenPosition;
    }

    private void SetMarkerVisible(bool visible)
    {
        if (markerImage != null)
        {
            markerImage.enabled = visible;
        }
    }
}