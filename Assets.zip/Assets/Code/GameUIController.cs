using TMPro;
using UnityEngine;

public class GameUIController : MonoBehaviour
{
    [Header("UI")]
    [SerializeField] private TextMeshProUGUI statusText;

    [Header("Stage Info")]
    [SerializeField] private float timeLimit = 300f;

    private float timer;

    private int score;
    private int remainingEnemies;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        timer = timeLimit;
    }

    // Update is called once per frame
    void Update()
    {
        UpdateTimer();
        UpdateStatusUI();
    }
    private void UpdateTimer()
    {
        timer -= Time.deltaTime;
        timer = Mathf.Max(timer, 0f);
    }

    private void UpdateStatusUI()
    {
        int minutes = Mathf.FloorToInt(timer / 60f);
        int seconds = Mathf.FloorToInt(timer % 60f);

        statusText.text =
            $"TIME  {minutes:00}:{seconds:00}\n" +
            $"SCORE {score}\n" +
            $"ENEMY {remainingEnemies}";
    }
    public void SetScore(int value)
    {
        score = value;
    }

    public void SetRemainingEnemies(int value)
    {
        remainingEnemies = value;
    }
}
