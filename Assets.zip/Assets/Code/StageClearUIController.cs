using TMPro;
using UnityEngine;

public class StageClearUIController : MonoBehaviour
{
    [SerializeField] private GameObject clearPanel;
    [SerializeField] private TextMeshProUGUI resultText;

    void Start()
    {
        if (clearPanel != null)
        {
            clearPanel.SetActive(false);
        }
    }

    public void ShowResult(ScoreResult result)
    {
        if (clearPanel != null)
        {
            clearPanel.SetActive(true);
        }

        resultText.text =
            $"STAGE CLEAR\n\n" +
            $" ENEMY SCORE : {result.KillScore}\n" +
            $" TIME SCORE  : {result.TimeScore}\n" +
            $" HP SCORE    : {result.HpScore}\n\n" +
            $" TOTAL SCORE : {result.TotalScore}";
    }
}