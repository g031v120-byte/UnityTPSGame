using UnityEngine;

public class PlayerShootController : MonoBehaviour
{
    [SerializeField] private GameObject bulletPrefab;
    [SerializeField] private Transform weaponPoint;
    [SerializeField] private Animator animator;

    [SerializeField] private int maxAmmo = 30;
    [SerializeField] private float reloadTime = 2f;

    private int currentAmmo;
    private bool isReloading;
    private float reloadTimer;

    public int CurrentAmmo => currentAmmo;
    public int MaxAmmo => maxAmmo;
    public bool IsReloading => isReloading;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        currentAmmo = maxAmmo;
    }

    // Update is called once per frame
    void Update()
    {
        if (isReloading)
        {
            reloadTimer -= Time.deltaTime;

            if (reloadTimer <= 0f)
            {
                FinishReload();
            }

            return;
        }

        if (Input.GetMouseButtonDown(0))
        {
            TryShoot();
        }

        if (Input.GetKeyDown(KeyCode.R))
        {
            StartReload();
        }
    }

    private void TryShoot()
    {
        if (currentAmmo <= 0)
        {
            StartReload();
            return;
        }

        Instantiate(
            bulletPrefab,
            weaponPoint.position,
            weaponPoint.rotation
        );

        currentAmmo--;

        if (animator != null)
        {
            animator.SetTrigger("Shoot");
        }
    }

    private void StartReload()
    {
        if (currentAmmo >= maxAmmo) return;

        isReloading = true;
        reloadTimer = reloadTime;
        if (animator != null)
        {
            animator.SetTrigger("Reload");
            animator.SetBool("IsReloading", true);
        }
    }

    private void FinishReload()
    {
        currentAmmo = maxAmmo;
        isReloading = false;
        if (animator != null)
        {
            animator.SetBool("IsReloading", false);
        }
    }
}
