using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class PlayerUIController : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private PlayerStatus playerStatus;
    [SerializeField] private PlayerShootController playerShootController;

    [Header("UI")]
    [SerializeField] private Slider hpSlider;
    [SerializeField] private TextMeshProUGUI ammoText;
    [SerializeField] private TextMeshProUGUI reloadText;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        hpSlider.maxValue = playerStatus.MaxHP;
    }

    // Update is called once per frame
    void Update()
    {
        UpdateHPUI();
        UpdateAmmoUI();
        UpdateReloadUI();
    }
    private void UpdateHPUI()
    {
        hpSlider.value = playerStatus.CurrentHP;
    }

    private void UpdateAmmoUI()
    {
        ammoText.text =
            $"{playerShootController.CurrentAmmo} / {playerShootController.MaxAmmo}";
    }

    private void UpdateReloadUI()
    {
        if (playerShootController.IsReloading)
        {
            reloadText.text = "RELOAD";
        }
        else
        {
            reloadText.text = "";
        }
    }
}
