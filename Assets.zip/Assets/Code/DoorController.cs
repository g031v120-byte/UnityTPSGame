using UnityEngine;

public class DoorController : MonoBehaviour
{
    [SerializeField] public float openHeight = 15f;
    [SerializeField] public float openSpeed = 2f;

    private Vector3 closedPosition;
    private Vector3 openPosition;
    private bool isOpen;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        closedPosition = transform.position;
        openPosition = closedPosition + Vector3.up * openHeight;
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 target = isOpen ? openPosition : closedPosition;

        transform.position = Vector3.MoveTowards(transform.position, target, openSpeed * Time.deltaTime);
    }
    public void OpenDoor()
    {
        isOpen = true;
    }

    public void CloseDoor()
    {
        isOpen = false;
    }
}
