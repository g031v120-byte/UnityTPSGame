using UnityEditor.EditorTools;
using UnityEngine;

public class EnemyController : MonoBehaviour
{
    [SerializeField] private RoomController roomController;
    [SerializeField] private int maxHP = 3;
    [SerializeField] private ScoreManager scoreManager;

    private int currentHP;
    private bool isDead;
    
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        currentHP = maxHP;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.K))
        {
            TakeDamage(1);
        }
    }
    public void TakeDamage(int damage)
    {
        if (isDead) return;

        currentHP -= damage;

        if (currentHP < 0) 
        {
            Die();
        }
    }

    private void Die()
    {
        isDead = true;

        if (roomController != null)
        {
            roomController.OnEnemyDefeated();
        }
        if (scoreManager != null)
        {
            scoreManager.AddEnemyKill();
        }

        Destroy(gameObject);
    }
}
