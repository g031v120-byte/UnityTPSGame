using UnityEngine;

public class EnemyAI_ChaseShooter : MonoBehaviour
{
    [SerializeField] private Transform target;

    [SerializeField] private float moveSpeed = 3f;
    [SerializeField] private float stopDistance = 5f;

    void Update()
    {
        if (target == null) return;

        Vector3 direction =
            target.position - transform.position;

        direction.y = 0f;

        float distance = direction.magnitude;

        if (distance > stopDistance)
        {
            direction.Normalize();

            transform.position +=
                direction * moveSpeed * Time.deltaTime;

            Quaternion targetRotation =
                Quaternion.LookRotation(direction);

            transform.rotation =
                Quaternion.Slerp(
                    transform.rotation,
                    targetRotation,
                    10f * Time.deltaTime
                );
        }
    }
}