using UnityEngine;

public class RoomController : MonoBehaviour
{
    [Header("Doors")]
    [SerializeField] private DoorController entranceDoor;
    [SerializeField] private DoorController exitDoor;
    [SerializeField] private DoorController nextEntranceDoor;

    [Header("Waves")]
    [SerializeField] private GameObject wave1Root;
    [SerializeField] private GameObject wave2Root;

    [SerializeField] private int wave1EnemyCount = 2;
    [SerializeField] private int wave2EnemyCount = 2;

    [Header("UI")]
    [SerializeField] private GameUIController gameUIController;
    [SerializeField] private ScoreManager scoreManager;
    [SerializeField] private StageClearUIController stageClearUIController;

    private int currentWave;
    private int remainingEnemies;

    private bool roomStarted;
    private bool roomCleared;

    void Start()
    {
        if (wave1Root != null)
        {
            wave1Root.SetActive(false);
        }

        if (wave2Root != null)
        {
            wave2Root.SetActive(false);
        }

        UpdateEnemyUI();
    }

    public void StartRoom()
    {
        if (roomStarted) return;

        roomStarted = true;

        if (entranceDoor != null)
        {
            entranceDoor.CloseDoor();
        }

        StartWave1();
    }

    private void StartWave1()
    {
        currentWave = 1;

        remainingEnemies = wave1EnemyCount;

        if (wave1Root != null)
        {
            wave1Root.SetActive(true);
        }

        UpdateEnemyUI();
    }

    private void StartWave2()
    {
        currentWave = 2;

        remainingEnemies = wave2EnemyCount;

        if (wave2Root != null)
        {
            wave2Root.SetActive(true);
        }

        UpdateEnemyUI();
    }

    public void OnEnemyDefeated()
    {
        if (roomCleared) return;

        remainingEnemies--;

        if (remainingEnemies < 0)
        {
            remainingEnemies = 0;
        }

        UpdateEnemyUI();

        if (remainingEnemies <= 0)
        {
            OnWaveCleared();
        }
    }

    private void OnWaveCleared()
    {
        if (currentWave == 1)
        {
            StartWave2();
        }
        else if (currentWave == 2)
        {
            ClearRoom();
        }
    }

    private void ClearRoom()
    {
        roomCleared = true;

        if (exitDoor != null)
        {
            exitDoor.OpenDoor();
        }

        if (nextEntranceDoor != null)
        {
            nextEntranceDoor.OpenDoor();
        }

        if (scoreManager != null && stageClearUIController != null)
        {
            ScoreResult result = scoreManager.StageClear();
            stageClearUIController.ShowResult(result);
        }
        UpdateEnemyUI();
    }

    private void UpdateEnemyUI()
    {
        if (gameUIController != null)
        {
            gameUIController.SetRemainingEnemies(remainingEnemies);
        }
    }
}