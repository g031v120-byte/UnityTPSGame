using UnityEngine;

public class EnemyShooter : MonoBehaviour
{
    [SerializeField] private GameObject bulletPrefab;
    [SerializeField] private Transform weaponPoint;
    [SerializeField] private Transform target;
    [SerializeField] private bool lookAtTarget = true;
    [SerializeField] private float rotateSpeed = 8f;

    [SerializeField] private float fireInterval = 2f;

    private float fireTimer;

    private void LookAtTarget()
    {
        if (target == null) return;

        Vector3 direction = target.position - transform.position;
        direction.y = 0f;

        if (direction.sqrMagnitude <= 0.01f) return;

        Quaternion targetRotation = Quaternion.LookRotation(direction);

        transform.rotation = Quaternion.Slerp(
            transform.rotation,
            targetRotation,
            rotateSpeed * Time.deltaTime
        );
    }
    void Update()
    {
        if (lookAtTarget)
        {
            LookAtTarget();
        }

        if (target == null) return;

        fireTimer += Time.deltaTime;

        if (fireTimer >= fireInterval)
        {
            fireTimer = 0f;
            ShootAtTarget();
        }
    }

    public void SetTarget(Transform newTarget)
    {
        target = newTarget;
    }

    public void ShootAtTarget()
    {
        if (bulletPrefab == null || weaponPoint == null || target == null)
        {
            return;
        }

        Vector3 direction = target.position - weaponPoint.position;
        direction.y = 0f;

        if (direction.sqrMagnitude <= 0.01f)
        {
            return;
        }

        Quaternion bulletRotation = Quaternion.LookRotation(direction);

        Instantiate(
            bulletPrefab,
            weaponPoint.position,
            bulletRotation
        );
    }
}