using UnityEngine;

public class ScoreManager : MonoBehaviour
{
    [SerializeField] private float timeLimit = 300f;
    [SerializeField] private PlayerStatus playerStatus;

    private float timer;
    private int killCount;
    private bool isCleared;

    public float RemainingTime => timer;
    public int KillCount => killCount;

    void Start()
    {
        timer = timeLimit;
    }

    void Update()
    {
        if (isCleared) return;

        timer -= Time.deltaTime;
        timer = Mathf.Max(timer, 0f);
    }

    public void AddEnemyKill()
    {
        killCount++;
    }

    public ScoreResult CalculateScore()
    {
        int killScore = killCount * 1000;
        int timeScore = Mathf.FloorToInt(timer / 60f) * 1000;

        int damage = playerStatus != null ? playerStatus.TotalDamageTaken : 0;
        int hpScore = 10000 - damage * 100;
        hpScore = Mathf.Max(hpScore, 0);

        int totalScore = killScore + timeScore + hpScore;

        return new ScoreResult(
            killScore,
            timeScore,
            hpScore,
            totalScore,
            killCount,
            Mathf.FloorToInt(timer)
        );
    }

    public ScoreResult StageClear()
    {
        isCleared = true;
        return CalculateScore();
    }
}

public class ScoreResult
{
    public int KillScore;
    public int TimeScore;
    public int HpScore;
    public int TotalScore;
    public int KillCount;
    public int RemainingTime;

    public ScoreResult(
        int killScore,
        int timeScore,
        int hpScore,
        int totalScore,
        int killCount,
        int remainingTime)
    {
        KillScore = killScore;
        TimeScore = timeScore;
        HpScore = hpScore;
        TotalScore = totalScore;
        KillCount = killCount;
        RemainingTime = remainingTime;
    }
}