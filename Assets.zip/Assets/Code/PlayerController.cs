using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UIElements;

public class PlayerController : MonoBehaviour
{
    public Transform cameraTransform;
    public float speed = 5f;
    public float sensitivity = 2f;
    [SerializeField] private float rotateSpeed = 10f;
    [SerializeField] private float jumpPower = 7f;
    [SerializeField] private float gravity = -20f;
    private float verticalVelocity;
    CharacterController controller;
    public Transform cameraPivot;
    [SerializeField] private float lockOnRange = 700f;
    [SerializeField] private string enemyTag = "Enemy";
    private Transform lockOnTarget;
    private readonly System.Collections.Generic.List<Transform> lockOnCandidates = new();
    [SerializeField] private Animator animator;

    float yaw;
    float pitch;
    private bool isLockOn;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        controller = GetComponent<CharacterController>();
    }

    private void TryLockOnNearestEnemy()
    {
        UpdateLockOnCandidates();

        if (lockOnCandidates.Count == 0)
        {
            return;
        }

        lockOnTarget = lockOnCandidates[0];
        isLockOn = true;
    }

    private void SwitchLockOnTarget()
    {
        UpdateLockOnCandidates();

        if (lockOnCandidates.Count == 0)
        {
            ClearLockOn();
            return;
        }

        int currentIndex = lockOnCandidates.IndexOf(lockOnTarget);
        int nextIndex = currentIndex + 1;

        if (nextIndex >= lockOnCandidates.Count)
        {
            nextIndex = 0;
        }

        lockOnTarget = lockOnCandidates[nextIndex];
    }

    private void ClearLockOn()
    {
        isLockOn = false;
        lockOnTarget = null;
    }

    private void UpdateLockOnCandidates()
    {
        lockOnCandidates.Clear();

        GameObject[] enemies = GameObject.FindGameObjectsWithTag(enemyTag);

        foreach (GameObject enemy in enemies)
        {
            float distance = Vector3.Distance(transform.position, enemy.transform.position);

            if (distance <= lockOnRange)
            {
                lockOnCandidates.Add(enemy.transform);
            }
        }

        lockOnCandidates.Sort((a, b) =>
        {
            float distanceA = Vector3.Distance(transform.position, a.position);
            float distanceB = Vector3.Distance(transform.position, b.position);
            return distanceA.CompareTo(distanceB);
        });
    }
    public bool IsLockOn
    {
        get { return isLockOn; }
    }

    public Transform CurrentLockOnTarget
    {
        get { return lockOnTarget; }
    }

    // Update is called once per frame
    void Update()
    {
        float vertical = Input.GetAxis("Vertical");
        float horizontal = Input.GetAxis("Horizontal");
        float mouseX = Input.GetAxis("Mouse X");
        float mouseY = Input.GetAxis("Mouse Y");
        if (Input.GetMouseButtonDown(1))
        {
            if (isLockOn)
            {
                ClearLockOn();
            }
            else
            {
                TryLockOnNearestEnemy();
            }
        }
        if (Input.GetKeyDown(KeyCode.Tab))
        {
            if (isLockOn)
            {
                SwitchLockOnTarget();
            }
        }
        yaw += mouseX * sensitivity * Time.deltaTime;
        pitch -= mouseY * sensitivity * Time.deltaTime;
        pitch = Mathf.Clamp(pitch, -60f, 60f);
        cameraPivot.rotation = Quaternion.Euler(pitch, yaw, 0f);
        Vector3 cameraForward = cameraTransform.forward;
        cameraForward.y = 0f;
        Vector3 cameraRight = cameraTransform.right;
        cameraRight.y = 0f;
        Vector3 moveDirection = cameraForward * vertical + cameraRight * horizontal;
        moveDirection = moveDirection.normalized;
        if (controller.isGrounded)
        {
            if (verticalVelocity < 0f)
            {
                verticalVelocity = -1f;
            }

            if (Input.GetKeyDown(KeyCode.Space))
            {
                verticalVelocity = jumpPower;
            }
        }

        verticalVelocity += gravity * Time.deltaTime;

        Vector3 move = moveDirection * speed;
        move.y = verticalVelocity;

        controller.Move(move * Time.deltaTime);

        if (animator != null)
        {
            animator.SetBool("IsLockOn", isLockOn);
            animator.SetFloat("Speed", moveDirection.magnitude);
            animator.SetFloat("ForwardMove", vertical);
            animator.SetFloat("SideMove", horizontal);
        }

        if (isLockOn && lockOnTarget != null)
        {
            Vector3 targetDirection = lockOnTarget.position - transform.position;
            targetDirection.y = 0f;

            if (targetDirection.sqrMagnitude > 0.01f)
            {
                Quaternion targetRotation = Quaternion.LookRotation(targetDirection);

                transform.rotation = Quaternion.Slerp(
                    transform.rotation,
                    targetRotation,
                    rotateSpeed * Time.deltaTime
                );
            }
        }
        else
        {
            if (moveDirection.sqrMagnitude > 0.01f)
            {
                Quaternion targetRotation = Quaternion.LookRotation(moveDirection);

                transform.rotation = Quaternion.Slerp(
                    transform.rotation, targetRotation, rotateSpeed * Time.deltaTime);
            }
        }
    }
}

