using System.Collections;
using UnityEngine;

public class PlayerStatus : MonoBehaviour
{
    [SerializeField] private int maxHP = 100;
    [SerializeField] private Animator animator;
    [SerializeField] private GameOverController gameOverController;
    [SerializeField] private float gameOverDelay = 2f;

    private int currentHP;
    private int totalDamageTaken;
    private bool isDead;

    public int CurrentHP => currentHP;
    public int MaxHP => maxHP;
    public int TotalDamageTaken => totalDamageTaken;
    public bool IsDead => isDead;

    void Start()
    {
        currentHP = maxHP;
    }

    public void TakeDamage(int damage)
    {
        if (isDead) return;

        currentHP -= damage;
        totalDamageTaken += damage;
        currentHP = Mathf.Clamp(currentHP, 0, maxHP);

        if (currentHP <= 0)
        {
            Die();
        }
    }

    private void Die()
    {
        isDead = true;

        if (animator != null)
        {
            animator.SetTrigger("Dead");
        }

        StartCoroutine(GameOverRoutine());
    }

    private IEnumerator GameOverRoutine()
    {
        yield return new WaitForSeconds(gameOverDelay);

        if (gameOverController != null)
        {
            gameOverController.ShowGameOver();
        }
    }
}