using System.Collections;
using UnityEngine;

public class EnemyAI_StationaryBurst : MonoBehaviour
{
    [SerializeField] private EnemyShooter shooter;

    [SerializeField] private float burstInterval = 4f;
    [SerializeField] private int burstCount = 3;
    [SerializeField] private float burstShotInterval = 0.2f;

    private bool isBursting;

    void Update()
    {
        if (!isBursting)
        {
            StartCoroutine(BurstRoutine());
        }
    }

    private IEnumerator BurstRoutine()
    {
        isBursting = true;

        for (int i = 0; i < burstCount; i++)
        {
            shooter.ShootAtTarget();
            yield return new WaitForSeconds(burstShotInterval);
        }

        yield return new WaitForSeconds(burstInterval);

        isBursting = false;
    }
}